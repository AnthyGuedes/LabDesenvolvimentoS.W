package Beans;

import Conexao.Conexao;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {
    private Conexao conexao;
    private Connection conn;

    public CategoriaDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
     public void inserir(Categoria categoria) {
        String sql = "INSERT INTO categoria (nome) VALUES (?);";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, categoria.getNome());

            stmt.execute();
            System.out.println("CATEGORIA INSERIDA com sucesso!");

        } catch (SQLException ex) {
            System.out.println("Erro ao inserir categoria: " + ex.getMessage());
        }
    }


    public List<Categoria> getCategorias() {
        String sql = "SELECT * FROM categoria";
        List<Categoria> listaCategorias = new ArrayList<>();

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Categoria c = new Categoria();
                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));
                listaCategorias.add(c);
            }
        } catch (SQLException ex) {
            System.out.println("erro ao consultar: " + ex.getMessage());
        }

        return listaCategorias;
    }
}
