/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Beans;

/**
 *
 * @author guede
 */
import Conexao.Conexao;
import Beans.Professor;  
import Conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DisciplinaDAO {
    private Conexao conexao;
    private Connection conn;
    
    // Método para adicionar uma nova disciplina
    public void adicionarDisciplina(Disciplina disciplina) {
        String sql = "INSERT INTO Disciplina (nome, cargaHoraria, idProfessor) VALUES (?, ?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, disciplina.getNome());
            stmt.setInt(2, disciplina.getCargaHoraria());
            stmt.setInt(3, disciplina.getIdProfessor());

            stmt.executeUpdate();
            System.out.println("Disciplina adicionada com sucesso!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Método para buscar todos os professores
    public List<Professor> buscarProfessores() {
        String sql = "SELECT * FROM Professor";
        List<Professor> professores = new ArrayList<>();

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Professor professor = new Professor();
                professor.setId(rs.getInt("id"));
                professor.setNome(rs.getString("nome"));
                // Adicione mais campos conforme necessário
                professores.add(professor);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return professores;
    }
}
